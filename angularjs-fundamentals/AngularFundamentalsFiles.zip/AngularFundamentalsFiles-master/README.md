Angular Fundamentals Course
========================

The course is out of date. Angular 1.5 has released, and although all the code in this course works with 1.5, there is the new feature of components which you should learn about. Checking out Pluralsight's course on Angular 1.5 components after this course will keep you up to date.

**Testing Module:**
The testing portion of the course uses two files which weren't created in the course: UserData.js and UserResource.js. This was done to highlight testing services with dependencies. You can find those files in this github repo, and add them to your project so that you can follow along with the testing chapter.

**Executing server.sh:**
If you are on a Linux or OSX box, you may need to execute "chmod +x server.sh" in order to run the node web server, or you can execute it with "bash server.sh" from the bash shell.
