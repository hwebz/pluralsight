The code for this module is up at:

http://github.com/robconery/ember-user-admin