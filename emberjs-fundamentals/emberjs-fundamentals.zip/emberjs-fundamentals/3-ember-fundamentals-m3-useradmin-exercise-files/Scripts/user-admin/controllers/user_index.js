﻿UserAdmin.UserIndexController = Ember.ObjectController.extend({
    needs: ['user']
});