﻿UserAdmin.UserNotesController = Ember.ArrayController.extend({
    sortProperties: ["created_at"],
    sortAscending: false
});