
<form enctype="multipart/form-data" action="handle_img.php" method="post">
	Send this file: <input name="book_image" type="file" /><br />
	<input type="submit" value="Upload" />
</form>
