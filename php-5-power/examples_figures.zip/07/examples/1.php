<?php

print "Hello!\n";
<gobbledigook/>

?>
