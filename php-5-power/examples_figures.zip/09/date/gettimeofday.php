<?php
	print_r(gettimeofday());
