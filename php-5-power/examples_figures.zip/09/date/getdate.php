<?php
	print_r(getdate());
?>
