<?php
	$str = '\\h';
	preg_match('@\\h@', $str, $matches1);
	preg_match('@\\h@X', $str, $matches2);
?>
