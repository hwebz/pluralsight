<?php
preg_match('@([A-Za-z ]+)(?:hans)@', 'Derick Rethans', $matches);
print_r($matches);
?>
