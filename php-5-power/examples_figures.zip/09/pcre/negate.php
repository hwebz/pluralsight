<?php
	preg_match('/[^0-9]+/', 'PHP is released in 2005', $matches);
	print_r($matches);
?>
