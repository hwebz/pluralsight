<?php
	preg_match('/./', 'PHP 5', $matches);

	print_r($matches);
?>
