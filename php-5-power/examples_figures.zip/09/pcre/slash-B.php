<?php
	$string = "Testing";
	preg_match('@\B.+\B@', $string, $matches);
	print_r($matches);
?>
