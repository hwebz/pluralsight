<?php

$db = sqlite_factory("test.db");

var_dump($db);
