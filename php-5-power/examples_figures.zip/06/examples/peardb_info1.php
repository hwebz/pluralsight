<?php

require_once 'DB.php';

$dbh = DB::connect("mysql://test@localhost/test");

