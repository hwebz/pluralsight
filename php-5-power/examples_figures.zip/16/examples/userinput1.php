<?php
print "What is your quest? ";
$purpose = trim(fgets(STDIN));
?>
