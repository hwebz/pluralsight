#!/usr/bin/php -Cq
<?php
require_once "DB.php";
$db = DB::connect("mysql://....
