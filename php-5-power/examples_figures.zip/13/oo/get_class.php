<?php
	class BookPage {
	}

	$page = new BookPage;

	echo get_class($page), "\n";
?>
