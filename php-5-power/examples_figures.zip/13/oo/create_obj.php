<?php
	$person = NULL;
	$person->name = "Derick";

	var_dump($person);
?>
