<?php
	error_reporting(4095);
	$obj->foo = 'bar';
?>
