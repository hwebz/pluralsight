<?php
	class book {
		var $title;
		var $isbn;
	}


	$p5pp = new book;
?>
