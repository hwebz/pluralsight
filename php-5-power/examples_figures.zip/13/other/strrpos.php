<?php
	$str = "This is a short string.";

	var_dump(strrpos($str, "small"));
?>
