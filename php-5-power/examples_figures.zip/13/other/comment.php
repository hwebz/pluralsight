<?php
	// Single line

	/* Multi
	 * line
	 */

	/**
	 * PHP Documentor style
	 */
?>
