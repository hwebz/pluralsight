<html>
  <head>
    <title><?php echo htmlspecialchars($t->title);?></title>
  </head>
  <body>
    <h1><?php echo htmlspecialchars($t->title);?></h1>
    <p><?php echo htmlspecialchars($t->body);?></p>
  </body>
</html>
