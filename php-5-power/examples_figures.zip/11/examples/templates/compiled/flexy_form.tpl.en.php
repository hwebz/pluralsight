<html>
 <head><title><?php echo htmlspecialchars($t->title);?></title></head>
 <body bgcolor=white>
  <?php echo $this->elements['myform']->toHtmlnoClose();?></form>
 </body>
</html>
