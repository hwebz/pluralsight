<?php
/**
* @author Derick Rethans <derick@php.net>
* @filesource
* @package Examples
*/
/**
* This class has automatic version numbers
* @version $Id: version.php,v 1.4 2002/07/25 16:42:48 Derick exp $
* @author Derick Rethans <derick@php.net>
* @package Examples
*/
class source_foo {
}
?>
