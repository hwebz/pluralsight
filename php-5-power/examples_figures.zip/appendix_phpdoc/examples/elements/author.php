<?php
/**
* @package Examples
* @author Derick Rethans <derick@php.net>
*/

/**
* Super-duper resource management class
*
* @author  Derick Rethans <derick@php.net>
* @package Examples
*/
class ResourceManager {
}
?>
