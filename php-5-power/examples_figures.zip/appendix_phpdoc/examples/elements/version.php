<?php
/**
* @package Examples
* @author Derick Rethans <derick@php.net>
*/

/**
* This class has automatic version numbers
* @package Examples
* @version $Id: version.php,v 1.4 2002/07/25 16:42:48 Derick exp $
* @author Derick Rethans <derick@php.net>
*/
class foo {
}
?>
