<?php
/**
* @package Examples
*/

/**
 * @name PHP_BROKEN Is PHP broken?
 */
define("PHP_BROKEN", TRUE);

/**
 * @ignore
 */
define("PHP_BROKEN", FALSE);
?>
