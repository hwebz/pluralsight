<?php
/**
* @package Examples
* @author Derick Rethans <derick@php.net>
*/

/**
 * Class to modify files
 *
 * With this class you can easily modify existing files on your system.
 * {@internal The way this class does this is kinda stupid though... }}
 * @package Examples
 */
class Modify1 {
}

/**
 * Class Two to modify files
 *
 * With this class you can easily modify existing files on your system.
 * @package Examples
 * @access private
 */
class Modify2 {
}
?>
