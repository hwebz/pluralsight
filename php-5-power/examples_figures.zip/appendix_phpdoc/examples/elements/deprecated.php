<?php
/**
* @package Examples
* @author Derick Rethans <derick@php.net>
*/

/**
* @deprecated Removed in version 0.8.1.2
*/
function add_all_arrays() {
}
?>
