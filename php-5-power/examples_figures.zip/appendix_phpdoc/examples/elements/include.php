<?php
/**
* @package Examples
* @author Derick Rethans <derick@php.net>
*/

/**
* Require language data
*/
require_once 'language.php';

/**
* Include template
*/
include 'html/template.php';
?>
