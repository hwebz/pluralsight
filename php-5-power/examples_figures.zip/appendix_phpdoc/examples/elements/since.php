<?php
/**
* @package Examples
* @author Derick Rethans <derick@php.net>
*/

/**
 * Returns the tabOffset
 * 
 * @since     1.5
 * @return    void
 */
function getTabOffset()
{
    return $this->_tabOffset;
}
?>
