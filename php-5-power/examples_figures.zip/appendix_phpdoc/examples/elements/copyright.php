<?php
/**
* Copyright example
* @package Examples
* @author Derick Rethans <derick@php.net>
* @copyright Copyright � 2002, Derick Rethans
*/

/**
* Stolen function
* @copyright Copyright � 1986-2002, Nanosoft
*/
function crash_computer() {
}
?>
